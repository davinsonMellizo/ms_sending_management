package co.com.bancolombia.model.log;
import lombok.Builder;
import lombok.Data;

@Data
@Builder(toBuilder = true)
public class Log {
    private String message;
}
