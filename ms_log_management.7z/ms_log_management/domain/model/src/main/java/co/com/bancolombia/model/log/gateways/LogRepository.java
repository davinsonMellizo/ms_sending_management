package co.com.bancolombia.model.log.gateways;

public interface LogRepository {
}
