package co.com.bancolombia.sqs.handler;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.jashmore.sqs.argument.payload.Payload;
import lombok.RequiredArgsConstructor;
import org.springframework.cloud.aws.messaging.config.annotation.EnableSqs;
import org.springframework.cloud.aws.messaging.listener.SqsMessageDeletionPolicy;
import org.springframework.cloud.aws.messaging.listener.annotation.SqsListener;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

@RequiredArgsConstructor
@EnableSqs
@Component
@Profile({"local"})
public class LogHandlerLocal {

    @SqsListener(value = "${cloud.aws.sqs.queue-endpoint}", deletionPolicy = SqsMessageDeletionPolicy.ALWAYS)
    public void listenLogBySqsListener(@Payload final String jsonMessage) throws JsonProcessingException {
        System.out.println("Mensaje leido, procediendo a enviar"+jsonMessage);

    }

}